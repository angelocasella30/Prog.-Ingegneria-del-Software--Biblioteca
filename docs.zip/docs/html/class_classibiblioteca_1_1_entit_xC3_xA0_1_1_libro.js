var class_classibiblioteca_1_1_entit_xC3_xA0_1_1_libro =
[
    [ "toString", "class_classibiblioteca_1_1_entit_xC3_xA0_1_1_libro.html#a6cbeabbe13e79a348d81e96e55b584d6", null ]
];