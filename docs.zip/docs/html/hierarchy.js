var hierarchy =
[
    [ "Classibiblioteca.Controllers.GestioneLibriController", "class_classibiblioteca_1_1_controllers_1_1_gestione_libri_controller.html", null ],
    [ "Classibiblioteca.Controllers.GestionePrestitiController", "class_classibiblioteca_1_1_controllers_1_1_gestione_prestiti_controller.html", null ],
    [ "Classibiblioteca.Controllers.GestioneUtentiController", "class_classibiblioteca_1_1_controllers_1_1_gestione_utenti_controller.html", null ],
    [ "com.mycompany.gestionebiblio.Main", "classcom_1_1mycompany_1_1gestionebiblio_1_1_main.html", null ],
    [ "Classibiblioteca.Controllers.MainController", "class_classibiblioteca_1_1_controllers_1_1_main_controller.html", null ],
    [ "Serializable", null, [
      [ "Classibiblioteca.Archivio", "class_classibiblioteca_1_1_archivio.html", null ],
      [ "Classibiblioteca.Bibliotecario", "class_classibiblioteca_1_1_bibliotecario.html", null ],
      [ "Classibiblioteca.Entità.Libro", "class_classibiblioteca_1_1_entit_xC3_xA0_1_1_libro.html", null ],
      [ "Classibiblioteca.Entità.Prestito", "class_classibiblioteca_1_1_entit_xC3_xA0_1_1_prestito.html", null ],
      [ "Classibiblioteca.Entità.Utente", "class_classibiblioteca_1_1_entit_xC3_xA0_1_1_utente.html", null ],
      [ "Classibiblioteca.tipologiearchivi.ArchivioLibri", "class_classibiblioteca_1_1tipologiearchivi_1_1_archivio_libri.html", null ],
      [ "Classibiblioteca.tipologiearchivi.ArchivioPrestiti", "class_classibiblioteca_1_1tipologiearchivi_1_1_archivio_prestiti.html", null ],
      [ "Classibiblioteca.tipologiearchivi.ArchivioUtenti", "class_classibiblioteca_1_1tipologiearchivi_1_1_archivio_utenti.html", null ]
    ] ],
    [ "serializable", null, [
      [ "Classibiblioteca.Entità.Libro", "class_classibiblioteca_1_1_entit_xC3_xA0_1_1_libro.html", null ],
      [ "Classibiblioteca.Entità.Utente", "class_classibiblioteca_1_1_entit_xC3_xA0_1_1_utente.html", null ],
      [ "Classibiblioteca.tipologiearchivi.ArchivioLibri", "class_classibiblioteca_1_1tipologiearchivi_1_1_archivio_libri.html", null ],
      [ "Classibiblioteca.tipologiearchivi.ArchivioPrestiti", "class_classibiblioteca_1_1tipologiearchivi_1_1_archivio_prestiti.html", null ],
      [ "Classibiblioteca.tipologiearchivi.ArchivioUtenti", "class_classibiblioteca_1_1tipologiearchivi_1_1_archivio_utenti.html", null ]
    ] ]
];