var class_classibiblioteca_1_1_controllers_1_1_main_controller =
[
    [ "initialize", "class_classibiblioteca_1_1_controllers_1_1_main_controller.html#a6e3d05203acf2d9856db6ff93b345967", null ]
];