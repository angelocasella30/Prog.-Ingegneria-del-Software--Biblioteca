var class_classibiblioteca_1_1_entit_xC3_xA0_1_1_utente =
[
    [ "toString", "class_classibiblioteca_1_1_entit_xC3_xA0_1_1_utente.html#a10d7f53442723ec07a98514d09ab3c03", null ]
];