var class_classibiblioteca_1_1_controllers_1_1_gestione_libri_controller =
[
    [ "initData", "class_classibiblioteca_1_1_controllers_1_1_gestione_libri_controller.html#aa340861920037c798ff8180030f0566f", null ],
    [ "initialize", "class_classibiblioteca_1_1_controllers_1_1_gestione_libri_controller.html#a63384fa3760a88c83fc51868327027a0", null ]
];