var annotated_dup =
[
    [ "Classibiblioteca", null, [
      [ "Controllers", null, [
        [ "GestioneLibriController", "class_classibiblioteca_1_1_controllers_1_1_gestione_libri_controller.html", "class_classibiblioteca_1_1_controllers_1_1_gestione_libri_controller" ],
        [ "GestionePrestitiController", "class_classibiblioteca_1_1_controllers_1_1_gestione_prestiti_controller.html", "class_classibiblioteca_1_1_controllers_1_1_gestione_prestiti_controller" ],
        [ "GestioneUtentiController", "class_classibiblioteca_1_1_controllers_1_1_gestione_utenti_controller.html", "class_classibiblioteca_1_1_controllers_1_1_gestione_utenti_controller" ],
        [ "MainController", "class_classibiblioteca_1_1_controllers_1_1_main_controller.html", "class_classibiblioteca_1_1_controllers_1_1_main_controller" ]
      ] ],
      [ "Entità", null, [
        [ "Libro", "class_classibiblioteca_1_1_entit_xC3_xA0_1_1_libro.html", "class_classibiblioteca_1_1_entit_xC3_xA0_1_1_libro" ],
        [ "Prestito", "class_classibiblioteca_1_1_entit_xC3_xA0_1_1_prestito.html", "class_classibiblioteca_1_1_entit_xC3_xA0_1_1_prestito" ],
        [ "Utente", "class_classibiblioteca_1_1_entit_xC3_xA0_1_1_utente.html", "class_classibiblioteca_1_1_entit_xC3_xA0_1_1_utente" ]
      ] ],
      [ "tipologiearchivi", null, [
        [ "ArchivioLibri", "class_classibiblioteca_1_1tipologiearchivi_1_1_archivio_libri.html", null ],
        [ "ArchivioPrestiti", "class_classibiblioteca_1_1tipologiearchivi_1_1_archivio_prestiti.html", null ],
        [ "ArchivioUtenti", "class_classibiblioteca_1_1tipologiearchivi_1_1_archivio_utenti.html", null ]
      ] ],
      [ "Archivio", "class_classibiblioteca_1_1_archivio.html", null ],
      [ "Bibliotecario", "class_classibiblioteca_1_1_bibliotecario.html", null ]
    ] ],
    [ "com", null, [
      [ "mycompany", null, [
        [ "gestionebiblio", null, [
          [ "Main", "classcom_1_1mycompany_1_1gestionebiblio_1_1_main.html", null ]
        ] ]
      ] ]
    ] ]
];