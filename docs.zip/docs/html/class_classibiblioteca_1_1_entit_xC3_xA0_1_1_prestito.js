var class_classibiblioteca_1_1_entit_xC3_xA0_1_1_prestito =
[
    [ "toString", "class_classibiblioteca_1_1_entit_xC3_xA0_1_1_prestito.html#ab3529aea6675cba586113042d9d3e6cb", null ]
];