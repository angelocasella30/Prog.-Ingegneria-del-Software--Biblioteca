var searchData=
[
  ['gestionelibricontroller_0',['GestioneLibriController',['../class_classibiblioteca_1_1_controllers_1_1_gestione_libri_controller.html',1,'Classibiblioteca::Controllers']]],
  ['gestioneprestiticontroller_1',['GestionePrestitiController',['../class_classibiblioteca_1_1_controllers_1_1_gestione_prestiti_controller.html',1,'Classibiblioteca::Controllers']]],
  ['gestioneutenticontroller_2',['GestioneUtentiController',['../class_classibiblioteca_1_1_controllers_1_1_gestione_utenti_controller.html',1,'Classibiblioteca::Controllers']]]
];
