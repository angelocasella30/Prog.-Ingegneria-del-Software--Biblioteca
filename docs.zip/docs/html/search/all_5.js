var searchData=
[
  ['libro_0',['Libro',['../class_classibiblioteca_1_1_entit_xC3_xA0_1_1_libro.html',1,'Classibiblioteca::Entità']]]
];
