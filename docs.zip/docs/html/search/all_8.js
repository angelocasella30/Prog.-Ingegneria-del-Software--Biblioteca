var searchData=
[
  ['salvaarchivio_0',['salvaArchivio',['../class_classibiblioteca_1_1_archivio.html#acfbb5ade9341b3d7cd31da8dd65af1fd',1,'Classibiblioteca::Archivio']]]
];
