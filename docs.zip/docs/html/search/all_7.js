var searchData=
[
  ['prestito_0',['Prestito',['../class_classibiblioteca_1_1_entit_xC3_xA0_1_1_prestito.html',1,'Classibiblioteca::Entità']]]
];
