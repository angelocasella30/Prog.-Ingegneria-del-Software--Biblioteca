var searchData=
[
  ['archivio_0',['Archivio',['../class_classibiblioteca_1_1_archivio.html',1,'Classibiblioteca']]],
  ['archiviolibri_1',['ArchivioLibri',['../class_classibiblioteca_1_1tipologiearchivi_1_1_archivio_libri.html',1,'Classibiblioteca::tipologiearchivi']]],
  ['archivioprestiti_2',['ArchivioPrestiti',['../class_classibiblioteca_1_1tipologiearchivi_1_1_archivio_prestiti.html',1,'Classibiblioteca::tipologiearchivi']]],
  ['archivioutenti_3',['ArchivioUtenti',['../class_classibiblioteca_1_1tipologiearchivi_1_1_archivio_utenti.html',1,'Classibiblioteca::tipologiearchivi']]]
];
