var searchData=
[
  ['main_0',['Main',['../classcom_1_1mycompany_1_1gestionebiblio_1_1_main.html',1,'com::mycompany::gestionebiblio']]],
  ['maincontroller_1',['MainController',['../class_classibiblioteca_1_1_controllers_1_1_main_controller.html',1,'Classibiblioteca::Controllers']]]
];
