var searchData=
[
  ['utente_0',['Utente',['../class_classibiblioteca_1_1_entit_xC3_xA0_1_1_utente.html',1,'Classibiblioteca::Entità']]]
];
