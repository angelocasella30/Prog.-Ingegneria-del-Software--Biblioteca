var searchData=
[
  ['caricaarchivio_0',['caricaArchivio',['../class_classibiblioteca_1_1_archivio.html#ac4d7fd65c5540b28b260043e9157e804',1,'Classibiblioteca::Archivio']]]
];
