var searchData=
[
  ['bibliotecario_0',['Bibliotecario',['../class_classibiblioteca_1_1_bibliotecario.html',1,'Classibiblioteca']]]
];
