var searchData=
[
  ['tostring_0',['toString',['../class_classibiblioteca_1_1_entit_xC3_xA0_1_1_libro.html#a6cbeabbe13e79a348d81e96e55b584d6',1,'Classibiblioteca.Entità.Libro.toString()'],['../class_classibiblioteca_1_1_entit_xC3_xA0_1_1_prestito.html#ab3529aea6675cba586113042d9d3e6cb',1,'Classibiblioteca.Entità.Prestito.toString()'],['../class_classibiblioteca_1_1_entit_xC3_xA0_1_1_utente.html#a10d7f53442723ec07a98514d09ab3c03',1,'Classibiblioteca.Entità.Utente.toString()']]]
];
