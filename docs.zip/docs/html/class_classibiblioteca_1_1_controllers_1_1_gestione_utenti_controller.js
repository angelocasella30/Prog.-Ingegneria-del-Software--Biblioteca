var class_classibiblioteca_1_1_controllers_1_1_gestione_utenti_controller =
[
    [ "initData", "class_classibiblioteca_1_1_controllers_1_1_gestione_utenti_controller.html#a5c7b089c5663eabfd577c08f02274631", null ],
    [ "initialize", "class_classibiblioteca_1_1_controllers_1_1_gestione_utenti_controller.html#ad34211dd9cb7fa15a173da6d8e888745", null ]
];