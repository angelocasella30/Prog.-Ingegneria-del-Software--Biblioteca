var class_classibiblioteca_1_1_controllers_1_1_gestione_prestiti_controller =
[
    [ "initData", "class_classibiblioteca_1_1_controllers_1_1_gestione_prestiti_controller.html#a695da7898561c8ecc58941875d427687", null ],
    [ "initialize", "class_classibiblioteca_1_1_controllers_1_1_gestione_prestiti_controller.html#ae62ab721d897633a721c34aebcd068f5", null ]
];